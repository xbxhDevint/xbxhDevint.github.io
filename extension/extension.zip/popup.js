/*chrome.storage.local.get("userName", function(data){
    if (data.userName==undefined) {
        document.querySelector("#greeting").innerHTML = '<a id="link" target="_blank" href="https://www.classcard.net/Main">클래스카드</a>로 이동하여 확장프로그램을 사용하세요!'
    } else {
        document.querySelector("#greeting").innerHTML = `만나서 반갑습니다 ${data.userName}님`
    }
});*/
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentURL = tabs[0].url.split('/');
    if (currentURL[2]=='www.classcard.net' && currentURL[3]=='set') {
        document.getElementById('button').style.display = 'block';
        chrome.storage.local.set({ memorize: true }, () => {});
        document.getElementById('button').addEventListener('click', ()=>{
            window.open(`https://www.classcard.net/Memorize/${currentURL[4]}/6000/${currentURL[5]}`)
        });
    }
});